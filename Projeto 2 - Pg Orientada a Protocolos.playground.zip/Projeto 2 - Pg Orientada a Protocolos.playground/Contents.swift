import UIKit

// Protocolo 'Drawable' com um método 'draw'
protocol Drawable {
    func draw()
}

// Enums para representar diferentes formas
enum ShapeType {
    case circle
    case rectangle
    case triangle
}

// Struct para representar informações sobre uma forma
struct ShapeInfo {
    let type: ShapeType
    let color: String
}

// Função que cria uma forma com base no 'ShapeInfo' usando um enum switch
func createShape(info: ShapeInfo) -> Drawable {
    switch info.type {
    case .circle:
        return Circle(color: info.color)
    case .rectangle:
        return Rectangle(color: info.color)
    case .triangle:
        return Triangle(color: info.color)
    }
}

// Classe 'Circle' que adota o protocolo 'Drawable'
class Circle: Drawable {
    let color: String
    
    init(color: String) {
        self.color = color
    }
    
    func draw() {
        print("Desenhando um círculo de cor \(color)")
    }
}

// Classe 'Rectangle' que adota o protocolo 'Drawable'
class Rectangle: Drawable {
    let color: String
    
    init(color: String) {
        self.color = color
    }
    
    func draw() {
        print("Desenhando um retângulo de cor \(color)")
    }
}

// Classe 'Triangle' que adota o protocolo 'Drawable'
class Triangle: Drawable {
    let color: String
    
    init(color: String) {
        self.color = color
    }
    
    func draw() {
        print("Desenhando um triângulo de cor \(color)")
    }
}

// Crie um array de 'ShapeInfo' para diferentes formas
let shapesInfo: [ShapeInfo] = [
    ShapeInfo(type: .circle, color: "vermelho"),
    ShapeInfo(type: .rectangle, color: "azul"),
    ShapeInfo(type: .triangle, color: "verde")
]

// Crie formas com base nas informações usando a função 'createShape' e chame o método 'draw' para cada uma
for shapeInfo in shapesInfo {
    let shape = createShape(info: shapeInfo)
    shape.draw()
}

// Demonstração de um uso simples de concorrência com GCD
let queue = DispatchQueue(label: "com.example.myqueue", qos: .userInitiated)
queue.async {
    for i in 1...5 {
        print("Trabalho em segundo plano \(i)")
    }
}

for j in 1...5 {
    print("Trabalho na thread principal \(j)")
}

