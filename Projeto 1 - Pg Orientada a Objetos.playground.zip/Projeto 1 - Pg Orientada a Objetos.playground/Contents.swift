import SwiftUI

// Classe base para representar uma tarefa
class Task {
    var title: String
    private var completed: Bool

    init(title: String) {
        self.title = title
        self.completed = false
    }

    func markAsCompleted() {
        completed = true
    }

    func isCompleted() -> Bool {
        return completed
    }
}

// Subclasse que herda de Task
class SubTask: Task {
    var parentTask: Task

    init(title: String, parentTask: Task) {
        self.parentTask = parentTask
        super.init(title: title)
    }

    override func markAsCompleted() {
        super.markAsCompleted()
        print("Subtask completed: \(title)")
    }
}

// Enum para representar as prioridades das tarefas
enum Priority {
    case low, medium, high
}

// Classe de modelo que mantém uma lista de tarefas
class TaskList: ObservableObject {
    @Published var tasks: [Task] = []

    func addTask(title: String, priority: Priority) {
        let task = Task(title: title)
        tasks.append(task)
    }
}

struct ContentView: View {
    @ObservedObject var taskList = TaskList()
    @State private var newTaskTitle = ""
    @State private var selectedPriority: Priority = .medium

    var body: some View {
        NavigationView {
            List {
                ForEach(taskList.tasks, id: \.title) { task in
                    Text(task.title)
                        .font(self.getFontForPriority(task))
                        .foregroundColor(task.isCompleted() ? .gray : .black)
                        .onTapGesture {
                            if let subtask = task as? SubTask {
                                subtask.markAsCompleted()
                            } else {
                                task.markAsCompleted()
                            }
                        }
                }
            }
            .navigationBarTitle("Task List")
            .navigationBarItems(trailing: addButton)
        }
    }

    var addButton: some View {
        NavigationLink(destination: AddTaskView(taskList: taskList)) {
            Text("Add Task")
        }
    }

    func getFontForPriority(_ task: Task) -> Font {
        if let subtask = task as? SubTask {
            return subtask.isCompleted() ? .caption : .headline
        } else {
            return task.isCompleted() ? .caption : .headline
        }
    }
}

struct AddTaskView: View {
    @ObservedObject var taskList: TaskList
    @State private var newTaskTitle = ""
    @State private var selectedPriority: Priority = .medium

    var body: some View {
        Form {
            Section {
                TextField("Task Title", text: $newTaskTitle)
            }
            Section {
                Button("Add Task") {
                    taskList.addTask(title: newTaskTitle, priority: selectedPriority)
                }
            }
        }
        .navigationBarTitle("Add Task")
    }
}

